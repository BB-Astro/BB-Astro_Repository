#!/bin/bash
# ======================================================================
# BB-Astro LAcosmic - Installation Script
# ======================================================================
# This script installs Python dependencies for LAcosmic
# Run this AFTER installing via PixInsight Repository
# ======================================================================

echo ""
echo "======================================================================"
echo "  BB-Astro LAcosmic - Python Dependencies Setup"
echo "======================================================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Find Python
PYTHON=""
if [ -x "/opt/homebrew/bin/python3" ]; then
    PYTHON="/opt/homebrew/bin/python3"
elif [ -x "/usr/local/bin/python3" ]; then
    PYTHON="/usr/local/bin/python3"
elif command -v python3 &> /dev/null; then
    PYTHON=$(command -v python3)
fi

if [ -z "$PYTHON" ]; then
    echo -e "${RED}ERROR:${NC} Python 3 not found!"
    echo ""
    echo "Please install Python 3.7+ first:"
    echo "  macOS:  brew install python3"
    echo "  Linux:  sudo apt install python3 python3-pip"
    exit 1
fi

echo "Python found: $PYTHON"
echo ""
echo "Installing dependencies..."
echo ""

$PYTHON -m pip install --user astroscrappy astropy numpy

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}======================================================================"
    echo "  Installation Complete!"
    echo "======================================================================${NC}"
    echo ""
    echo "To use LAcosmic in PixInsight:"
    echo "  1. Restart PixInsight"
    echo "  2. Open an image"
    echo "  3. Go to: Script > BB-Astro > LAcosmic"
    echo ""
else
    echo ""
    echo -e "${RED}ERROR:${NC} Failed to install packages"
    echo "Try: $PYTHON -m pip install astroscrappy astropy numpy"
fi
