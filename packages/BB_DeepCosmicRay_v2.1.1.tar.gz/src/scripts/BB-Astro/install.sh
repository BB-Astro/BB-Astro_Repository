#!/bin/bash
# ======================================================================
# BB-Astro DeepCosmicRay - Installation Script
# ======================================================================
# This script sets up the Python environment for DeepCosmicRay
# Run this AFTER installing via PixInsight Repository
# ======================================================================

echo ""
echo "======================================================================"
echo "  BB-Astro DeepCosmicRay - Python Environment Setup"
echo "======================================================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="${HOME}/.bb-astro"
VENV_DIR="${INSTALL_DIR}/deepcr_venv"

# ======================================================================
# Step 1: Check Python
# ======================================================================
echo -e "${BLUE}[1/4]${NC} Checking Python installation..."

PYTHON=""
if [ -x "/opt/homebrew/bin/python3" ]; then
    PYTHON="/opt/homebrew/bin/python3"
elif [ -x "/usr/local/bin/python3" ]; then
    PYTHON="/usr/local/bin/python3"
elif command -v python3 &> /dev/null; then
    PYTHON=$(command -v python3)
fi

if [ -z "$PYTHON" ]; then
    echo -e "${RED}ERROR:${NC} Python 3 not found!"
    echo ""
    echo "Please install Python 3.8+ first:"
    echo "  macOS:  brew install python3"
    echo "  Linux:  sudo apt install python3 python3-venv python3-pip"
    echo ""
    exit 1
fi

PYTHON_VERSION=$($PYTHON --version 2>&1 | awk '{print $2}')
echo -e "${GREEN}OK${NC} Python found: $PYTHON (v$PYTHON_VERSION)"

# ======================================================================
# Step 2: Create virtual environment
# ======================================================================
echo ""
echo -e "${BLUE}[2/4]${NC} Creating virtual environment..."

mkdir -p "$INSTALL_DIR"

if [ -d "$VENV_DIR" ]; then
    echo -e "${YELLOW}!${NC} Virtual environment already exists at $VENV_DIR"
    read -p "   Recreate it? [y/N] " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "   Removing old venv..."
        rm -rf "$VENV_DIR"
    else
        echo "   Keeping existing venv, will update packages..."
    fi
fi

if [ ! -d "$VENV_DIR" ]; then
    echo "   Creating venv at $VENV_DIR ..."
    $PYTHON -m venv "$VENV_DIR"
    if [ $? -ne 0 ]; then
        echo -e "${RED}ERROR:${NC} Failed to create virtual environment"
        echo "   Try: $PYTHON -m pip install --user virtualenv"
        exit 1
    fi
fi

echo -e "${GREEN}OK${NC} Virtual environment ready"

# ======================================================================
# Step 3: Install Python packages
# ======================================================================
echo ""
echo -e "${BLUE}[3/4]${NC} Installing Python packages..."
echo "   This may take 2-5 minutes (PyTorch is large)..."
echo ""

source "$VENV_DIR/bin/activate"

# Upgrade pip
pip install --upgrade pip > /dev/null 2>&1

# Install packages
pip install numpy astropy xisf deepcr torch torchvision

if [ $? -ne 0 ]; then
    echo ""
    echo -e "${RED}ERROR:${NC} Failed to install packages"
    echo "   Try running manually:"
    echo "   source $VENV_DIR/bin/activate"
    echo "   pip install numpy astropy xisf deepcr torch torchvision"
    exit 1
fi

echo ""
echo -e "${GREEN}OK${NC} Python packages installed"

# ======================================================================
# Step 4: Download DeepCR model weights
# ======================================================================
echo ""
echo -e "${BLUE}[4/4]${NC} Downloading DeepCR model weights (~100 MB)..."
echo ""

"$VENV_DIR/bin/python3" << 'PYTHON_SCRIPT'
import sys
try:
    from deepCR import deepCR
    print("   Loading ACS-WFC-F606W-2-32 model...")
    model = deepCR(mask="ACS-WFC-F606W-2-32", device="cpu")
    print("   Model loaded and cached successfully!")
except Exception as e:
    print(f"   Warning: Could not pre-download model: {e}")
    print("   Model will be downloaded on first use.")
    sys.exit(0)
PYTHON_SCRIPT

echo ""
echo -e "${GREEN}OK${NC} DeepCR model ready"

# ======================================================================
# Done!
# ======================================================================
echo ""
echo "======================================================================"
echo -e "${GREEN}  Installation Complete!${NC}"
echo "======================================================================"
echo ""
echo "Virtual environment location:"
echo "  $VENV_DIR"
echo ""
echo "To use DeepCosmicRay in PixInsight:"
echo "  1. Restart PixInsight"
echo "  2. Open an image"
echo "  3. Go to: Script > BB-Astro > DeepCosmicRay"
echo ""
echo "For support: www.bb-astro.com"
echo "======================================================================"
echo ""
